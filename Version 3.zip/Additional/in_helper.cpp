#include <fstream>
#include <iostream>
#include <cstring>

#include "../Templates/State.h"

std::vector<char> parse_vector(const char *line)
{
    std::vector<char> res;
    for (const char *sim = line; *sim != '\0'; sim++)
    {
        res.push_back(*sim);
    }
    return res;
}


double g = 0.1;
double rho[256];

int main()
{
    State state;

    state.total_ticks = 1'000'000;
    state.tick = 0; // starting point

    constexpr uint32_t height = 36, width = 84;
    state.field = 
    {
        parse_vector("####################################################################################"),
        parse_vector("#                                                                                  #"),
        parse_vector("#                                                                                  #"),
        parse_vector("#                                                                                  #"),
        parse_vector("#                                                                                  #"),
        parse_vector("#                                                                                  #"),
        parse_vector("#                                       .........                                  #"),
        parse_vector("#..............#            #           .........                                  #"),
        parse_vector("#..............#            #           .........                                  #"),
        parse_vector("#..............#            #           .........                                  #"),
        parse_vector("#..............#            #                                                      #"),
        parse_vector("#..............#            #                                                      #"),
        parse_vector("#..............#            #                                                      #"),
        parse_vector("#..............#            #                                                      #"),
        parse_vector("#..............#............#                                                      #"),
        parse_vector("#..............#............#                                                      #"),
        parse_vector("#..............#............#                                                      #"),
        parse_vector("#..............#............#                                                      #"),
        parse_vector("#..............#............#                                                      #"),
        parse_vector("#..............#............#                                                      #"),
        parse_vector("#..............#............#                                                      #"),
        parse_vector("#..............#............#                                                      #"),
        parse_vector("#..............#............################                     #                 #"),
        parse_vector("#...........................#....................................#                 #"),
        parse_vector("#...........................#....................................#                 #"),
        parse_vector("#...........................#....................................#                 #"),
        parse_vector("##################################################################                 #"),
        parse_vector("#                                                                                  #"),
        parse_vector("#                                                                                  #"),
        parse_vector("#                                                                                  #"),
        parse_vector("#                                                                                  #"),
        parse_vector("#                                                                                  #"),
        parse_vector("#                                                                                  #"),
        parse_vector("#                                                                                  #"),
        parse_vector("#                                                                                  #"),
        parse_vector("####################################################################################"),
    };

    // constexpr size_t height = 14, width = 5;
    // state.field = {
    //     parse_vector("#####"),
    //     parse_vector("#.  #"),
    //     parse_vector("#.# #"),
    //     parse_vector("#.# #"),
    //     parse_vector("#.# #"),
    //     parse_vector("#.# #"),
    //     parse_vector("#.# #"),
    //     parse_vector("#.# #"),
    //     parse_vector("#...#"),
    //     parse_vector("#####"),
    //     parse_vector("#   #"),
    //     parse_vector("#   #"),
    //     parse_vector("#   #"),
    //     parse_vector("#####"),
    // };

    state.dirs = std::vector<std::vector<int>>(height, std::vector<int>(width));

    state.g = 0.1;
    state.rho[' '] = 0.01;
    state.rho['.'] = 1000;

    state.p = state.old_p = std::vector<std::vector<double>>(height, std::vector<double>(width));

    state.velocity = state.velocity_flow = std::vector<std::vector<std::array<double, 4>>> (height, std::vector<std::array<double, 4>>(width));

    state.UT = 0;
    state.last_use = std::vector<std::vector<int>>(height, std::vector<int>(width));

    std::ofstream os("in.bin", std::ios::binary);
    size_t pack_size = state.getSize();
    os.write((char*)&pack_size, sizeof(pack_size));
    os << state;

    return 0;
}