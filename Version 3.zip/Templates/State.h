#pragma once

#include <iostream>
#include <vector>
#include <array>

// current imitation state
struct State
{
private:

    template <typename T>
    static void write_vec(std::ostream &os, const std::vector<std::vector<T>> &v)
    {
        for (size_t i = 0; i < v.size(); i++)
        {
            os.write((char*)v[i].data(), sizeof(T) * v.begin()->size());
        }
    }

    template <typename T>
    static void read_vec(std::istream &is, std::vector<std::vector<T>> &v, size_t rows, size_t cols)
    {
        v = std::vector<std::vector<T>>(rows, std::vector<T>(cols));
        for (size_t i = 0; i < v.size(); i++)
        {
            is.read((char*)v[i].data(), sizeof(T) * v.begin()->size());
        }
    }

public:
    size_t total_ticks = 0;
    size_t tick = 0;
    size_t save_frequency = 0;

    std::vector<std::vector<char>> field;
    std::vector<std::vector<int>> dirs;

    double rho[256] {};
    double g = 0.1;
    
    std::vector<std::vector<double>> p;
    std::vector<std::vector<double>> old_p;

    std::vector<std::vector<std::array<double, 4>>> velocity;
    std::vector<std::vector<std::array<double, 4>>> velocity_flow;

    int UT;
    std::vector<std::vector<int>> last_use;

    State() = default;
    State(State &&state) = default;

    size_t getSize() const
    {
        return 4 * sizeof(size_t) + 257 * sizeof(double) + sizeof(int) + field.size() * field.begin()->size() * (sizeof(char) + 2 * sizeof(int) + 10 * sizeof(double));
    }

    friend std::ostream &operator<<(std::ostream &os, const State &state)
    {
        size_t rows = state.field.size();
        size_t cols = state.field.begin()->size();

        os.write((char*)&state.total_ticks, sizeof(state.total_ticks));
        os.write((char*)&state.tick, sizeof(state.tick));

        os.write((char*)&rows, sizeof(rows));
        os.write((char*)&cols, sizeof(cols));

        write_vec(os, state.field);
        write_vec(os, state.dirs);

        os.write((char*)&state.rho[0], sizeof(double) * 256);
        os.write((char*)&state.g, sizeof(double));

        write_vec(os, state.p);
        write_vec(os, state.old_p);

        for (size_t i = 0; i < rows; i++)
        {
            for (size_t j = 0; j < cols; j++)
            {
                os.write((char*)state.velocity[i][j].data(), sizeof(double) * state.velocity[i][j].size());
            }
        }

        for (size_t i = 0; i < rows; i++)
        {
            for (size_t j = 0; j < cols; j++)
            {
                os.write((char*)state.velocity_flow[i][j].data(), sizeof(double) * state.velocity_flow[i][j].size());
            }
        }

        os.write((char*)&state.UT, sizeof(state.UT));
        write_vec(os, state.last_use);

        return os;
    }

    friend std::istream &operator>>(std::istream &is, State &state)
    {
        is.read((char*)&state.total_ticks, sizeof(state.total_ticks));
        is.read((char*)&state.tick, sizeof(state.tick));

        size_t rows, cols;
        is.read((char*)&rows, sizeof(rows));
        is.read((char*)&cols, sizeof(cols));

        read_vec(is, state.field, rows, cols);
        read_vec(is, state.dirs, rows, cols);
        is.read((char*)&state.rho[0], sizeof(double) * 256);
        is.read((char*)&state.g, sizeof(double));

        read_vec(is, state.p, rows, cols);
        read_vec(is, state.old_p, rows, cols);

        state.velocity = std::vector<std::vector<std::array<double, 4>>>(rows,
        std::vector<std::array<double, 4>>(cols));
        for (size_t i = 0; i < rows; i++)
        {
            for (size_t j = 0; j < cols; j++)
            {
                is.read((char*)state.velocity[i][j].data(), sizeof(double) * 4);  
            }   
        }

        state.velocity_flow = std::vector<std::vector<std::array<double, 4>>>(rows,
        std::vector<std::array<double, 4>>(cols));
        for (size_t i = 0; i < rows; i++)
        {
            for (size_t j = 0; j < cols; j++)
            {
                is.read((char*)state.velocity[i][j].data(), sizeof(double) * 4);  
            }   
        }
        

        is.read((char*)&state.UT, sizeof(state.UT));
        read_vec(is, state.last_use, rows, cols);

        return is;
    }
};