#include <iostream>
#include <vector>
#include <sstream>

#include "./Templates/TypeInfo.h"
#include "./Templates/Imitation.h"


#include "./Templates/Switch.h"
#include "./Templates/State.h"


std::string parse_arg(const std::string &arg)
{
    std::string res = "";
    for (auto sim = arg.begin() + arg.find('=') + 1; sim != arg.end(); ++sim)
    {
        if (!std::isspace(*sim))
        {
            res.push_back(*sim);
        }
    }
    return res;
}

int main(int argc, char *argv[])
{
    if (argc < 4)
    {
        std::cerr << "Not enough arguments provided!\n";
        exit(-1);
    }

    std::string in_file = "in.bin", storage_file = "storage.bin", type1, type2, type3, arg;
    size_t save_index = 0; // starting frame index
    size_t save_frequency = 0; // save_frequency == 0 => never save

    // parsing arguments
    for (int i = 1; i < argc; i++)
    {
        arg = std::string(argv[i]);
        if (arg.starts_with("--p-type"))
        {
            type1 = parse_arg(arg);
        }
        else if (arg.starts_with("--v-type"))
        {
            type2 = parse_arg(arg);
        }
        else if (arg.starts_with("--v-flow-type"))
        {
            type3 = parse_arg(arg);
        }
        else if (arg.starts_with("--in-file"))
        {
            in_file = parse_arg(arg);
        }
        else if (arg.starts_with("--storage-file"))
        {
            storage_file = parse_arg(arg);
        }
        else if (arg.starts_with("--save-index"))
        {
            save_index = std::stoi(parse_arg(arg));
        }
        else if (arg.starts_with("--save-frequency"))
        {
            save_frequency = std::stoi(parse_arg(arg));
        }
        else
        {
            std::cerr << "Unknown command line argument: " << arg << '\n';
        }
    }

    if (type1.empty() || type2.empty() || type3.empty())
    {
        std::cerr << "Not all types provided!\n";
    }

    // reading start state
    State start_state;

    std::ifstream is(in_file, std::ios::binary);
    size_t pack_size;
    is.read((char*)&pack_size, sizeof(size_t));
    size_t offset = pack_size * save_index;

    is.seekg(offset, std::ios::cur);

    char test_char;
    is.read(&test_char, sizeof(char));
    if (is.eof())
    {
        std::cerr << "Save index = " << save_index << " > amount of states stored in " << in_file << '\n';
        exit(-1);
    }
    is.seekg(-1, std::ios::cur);

    is >> start_state;
    start_state.save_frequency = save_frequency;


    Binder binder;
    binder.bind(type1, type2, type3, std::move(start_state), storage_file);
    return 0;
}
